package com.example.clean_news_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
