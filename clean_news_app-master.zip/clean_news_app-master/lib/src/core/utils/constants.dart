const String kMaterialAppTitle = 'Flutter Clean Architecture';

// API
const String kBaseUrl = 'https://newsapi.org/v2';

const String kApiKey = 'ed7bd53fecd9401e82481dfd658383a9';


